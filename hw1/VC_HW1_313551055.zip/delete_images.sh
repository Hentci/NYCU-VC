#!/bin/bash

# 刪除8張輸出的灰階圖片
rm -f R_channel.png
rm -f G_channel.png
rm -f B_channel.png
rm -f Y_channel.png
rm -f U_channel.png
rm -f V_channel.png
rm -f Cb_channel.png
rm -f Cr_channel.png

echo "Images deleted."