執行 `python3 color_transform.py` 便會自動生成作業要求的 8 張圖片
`sh delete_images.sh`則會刪除所有輸出